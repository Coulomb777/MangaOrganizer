plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "jp.example.mangaorganizer"
    compileSdk = 35
    defaultConfig {
        applicationId = "jp.example.mangaorganizer"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("com.google.mlkit:text-recognition-japanese:16.0.1")
}
